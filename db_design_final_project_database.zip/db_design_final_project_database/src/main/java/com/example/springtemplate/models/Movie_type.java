package com.example.springtemplate.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


public enum Movie_type {
  ROMANCE,
  COMEDY,
  THRILLER,
  DOCUMENTARY,
  DRAMA;
}
